from .app import App


def start(img):
    root = App(img)
    root.mainloop()
