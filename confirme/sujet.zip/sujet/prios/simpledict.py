from priodict import EmptyDict

class SimpleDict(dict):
    """Version naïve avec un dictionnaire"""

    def pop_smallest(self):
        raise NotImplementedError("il faut coder uniquement pop_smallest !")
